package Clases;


public class Alumno {

    //Attributes
    private String nombre;
    private String apellidos;
    private String cedula;
    private String correo;
    private String seccion;
    private String telefono;
    private float promedio;
    private String errorpromedio;

    

        
    
    //Constructores
    public Alumno() { }
    public Alumno(String nombre, String apellidos, String cedula, String correo, String seccion, String telefono, float promedio, String errorpromedio) {
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.cedula = cedula;
        this.correo = correo;
        this.seccion = seccion;
        this.telefono = telefono;
        this.promedio = promedio;
        this.errorpromedio= errorpromedio;
    }
    
     
    //Metodos
    @Override
    public String toString() {
        return  "Nombre: " +this.nombre+       "\n"+
                "Apellidos: "  +this.apellidos+    "\n"+
                "Cedula: "  +this.cedula+    "\n"+
                "Correo: "  +this.correo+    "\n"+
                "Seccion: "  +this.seccion+    "\n"+
                "Telefono: "  +this.telefono+    "\n"+
                "Promedio: "  +this.promedio+         "\n"+
                this.errorpromedio+    "\n";
    }

    
    //Gets and Sets
    public String getNombre() {
        return nombre;
    }
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    public String getApellidos() {
        return apellidos;
    }
    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }
    
    public String getCedula() {
        return cedula;
    }

    public void setCedula(String cedula) {
        this.cedula = cedula;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getSeccion() {
        return seccion;
    }

    public void setSeccion(String seccion) {
        this.seccion = seccion;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public float getPromedio() {
        return promedio;
    }

    public void setPromedio(float promedio) {
        this.promedio = promedio;
    }
    
  public String getErrorpromedio() {
        return errorpromedio;
    }

    public void setErrorpromedio(String errorpromedio) {
        this.errorpromedio = errorpromedio;
    }

 
}