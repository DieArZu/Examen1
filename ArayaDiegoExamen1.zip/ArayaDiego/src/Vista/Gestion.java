
package Vista;

import java.util.List;
import Clases.*;
import Vista.Leer;

public class Gestion {

   
    public void mostrarMenu(){
        System.out.println("\n------\nElija la opcion que desea: \n"
                + "1.- Anadir alumnos \n"
                + "2.- Mostrar todos los alumnos \n"
                + "3.- Mostrar un alumno \n"
                + "4.- Modificar un alumno \n"
                + "5.- Borrar un alumno \n"
                + "OTRO NUMERO --> Salir");
    }


    public int menuEditar(){
        int eleccion = 0;
        do {
            System.out.println("\n------\nElija que desea editar: \n"
                    + "1.- Nombre n"
                    + "2.- Apellidos n"
                    + "3.- Seccion : 7-1 o 7-2 \n"
                    + "4.- Cedula \n");

            eleccion = Leer.datoInt();

        } while (eleccion < 0 || eleccion > 4);
        return eleccion;
    }

  
    public Alumno anadirAlumno(){
        String sec;
        String ced="";
        float pro=0;
        String errorpromedio;
        System.out.println("Introduzca nombre");    String nom  =   Leer.dato();
        System.out.println("Introduzca apellidos"); String ape  =   Leer.dato();
        System.out.println("Introduzca cedula");
        String cedrev    =   Leer.dato();
        if (cedrev.length()==12){
            ced=cedrev;
            }else{
                ced= "Error largo de cedula";
            }
        System.out.println("Introduzca correo");    String cor    =   Leer.dato();
        System.out.println("Introduzca seccion  1 para 7-1 o 2 para 7-2");
        String secrev    =   Leer.dato();
            if((secrev.equals("1")) || (secrev.equals("2"))){
                sec = "7-"+secrev; 
                }else{ 
                    sec = "Error en numero de seccion";    
                }
        System.out.println("Introduzca telefono");   String tel    =   Leer.dato();
        System.out.println("Introduzca promedio");   float revpro    =   Leer.datoFloat();
            if ( revpro>0){
                pro= revpro;
                errorpromedio = "";
            }else{ 
                pro= 0;
                errorpromedio= "Ingreso un promedio erroneo";
            }
        
        Alumno alum = new Alumno(nom, ape, ced, cor, sec , tel, pro, errorpromedio );

        return alum;
    }

    /**
     * Comprueba que el usuario ha introducido un objeto (Alumno) válido y existente en la colección de Alumnos
     * @param listaAlumnos      Colección (array) de los alumnos existentes
     * @param posicionAlumno    Posición de un objeto Alumno, introducida por el usuario, dentro la colección
     * @return                  Booleano que indica si existe dicho objeto
     */
    public boolean noVacio(List<Alumno> listaAlumnos, int posicionAlumno){
        boolean existeElemento = false;
        if (listaAlumnos.size() < posicionAlumno)   existeElemento = true;

        return existeElemento;
    }

    /**
     * Obtiene un alumno indicado por la posición que ocupa en la colección
     * @param listaAlumnos      Colección (array) de los alumnos existentes
     * @param posicionAlumno    Posición de un objeto Alumno, introducida por el usuario, dentro la colección
     * @return                  Devuelve un nuevo objeto alumno indicado por el usuario por su posición
     */
    public Alumno obtenerAlumno(List<Alumno> listaAlumnos, int posicionAlumno){
        //Llamada al método booleano "noVacio". Si no es válida la posición, no se continua
        while (this.noVacio(listaAlumnos, posicionAlumno)) {
            System.out.println("La posición elegida no existe. Por favor, introduzca otra");
            //Se solicita nueva posición
            posicionAlumno = Leer.datoInt();
        }
        //Devuelve el objeto alumno
        return listaAlumnos.get(posicionAlumno-1);
    }

    /**
     * Elimina un objeto alumno de la colección
     * @param listaAlumnos      Colección (array) de los alumnos existentes
     * @param posicionAlumno    Posición de un objeto Alumno, introducida por el usuario, dentro la colección
     */
    public void eliminarAlumno(List<Alumno> listaAlumnos, int posicionAlumno){
        //Llamada al método "obtenerAlumno" (recuerdo, este método ya se encarga de obtener una posición válida)
        //Se elimina el alumno con el método "remove" de ArrayList
        listaAlumnos.remove(this.obtenerAlumno(listaAlumnos, posicionAlumno));

        System.out.println("Registro eliminado correctamente");
    }

    /**
     * Permite editar nombre, apellidos y edad. Individualmente
     * @param listaAlumnos      Colección (array) de los alumnos existentes
     * @param posicionAlumno    Posición de un objeto Alumno, introducida por el usuario, dentro la colección
     */
    public void modificarAlumno(List<Alumno> listaAlumnos, int posicionAlumno){
        //Llamada al método "obtenerAlumno" (recuerdo, este método ya se encarga de obtener una posición válida)
        this.obtenerAlumno(listaAlumnos, posicionAlumno);

        //Se presenta el menú de edición. Posibilita: Editar nombre, apellidos y edad.
        //Se modifica con los "set" creados en la clase "Alumno"
        switch (this.menuEditar()) {
            case 1://Se modifica el nombre
                System.out.println("Introduzca el nuevo nombre");
                this.obtenerAlumno(listaAlumnos, posicionAlumno).setNombre(Leer.dato());
                break;
            case 2://Se modifican los apellidos
                System.out.println("Introduzca los nuevos apellidos");
                this.obtenerAlumno(listaAlumnos, posicionAlumno).setApellidos(Leer.dato());
                break;
            case 3://Se modifica la seccion
                System.out.println("Introduzca la nueva seccion 7-1 o 7-2");
                this.obtenerAlumno(listaAlumnos, posicionAlumno).setSeccion(Leer.dato());
                break;
            default://No es necesaria esta opción
                break;
        } System.out.println("Modificacion realizada correctamente");
    }
}