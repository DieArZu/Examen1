package Vista;

import java.util.*;
import Clases.*;
import java.util.ArrayList;
import java.util.List;

public class Inicio {

    public static void main(String[] args) {
     
        
        String usuario="";
        String clave="";
        String user = "admin";
        String clav = "adminadmin";
        int intentos=0;
        int max=3;
                
        Scanner teclado = new Scanner(System.in);
        
        System.out.println("Bienvenido al programa ADMINISTRADOR DE ALUMNOS de Setimo");
        
        while ( (!usuario.equals(user)) && (!clave.equals(clav)) && (intentos < max)) {
               System.out.println("Ingrese el usuario / opcion "+(intentos+1));
                usuario= teclado.next();
                System.out.println("Ingrese la clave");
                clave= teclado.next(); 
                System.out.println("----------");
                 
              
                
                intentos++;       
        
        }
                


        boolean repetir = true;
        int cantidadAlumnosInicial=5, posicionAlumno=0;
        int aux = 1;

        Gestion gestion = new Gestion();
        List<Alumno> listaAlumnos = new ArrayList<Alumno>(cantidadAlumnosInicial);

        if ((usuario.equals(user)) && (clave.equals(clav)) ){
        
        for (int i = 0; i < cantidadAlumnosInicial; i++) {
            System.out.println("Alumno "+(i+1));
            listaAlumnos.add(gestion.anadirAlumno());
        }

        do {
            gestion.mostrarMenu();
            switch (Leer.datoInt()) {
                case 1: //Añadir alumnos
                    listaAlumnos.add(gestion.anadirAlumno());
                    break;

                case 2: //Mostrar todos los alumnos
                    for (Alumno alumno : listaAlumnos) {
                        System.out.println(alumno.toString());
                        System.out.println("------");
                    }
                    break;

                case 3: //Mostrar un alumno
                    System.out.println("Que alumno desea mostrar");
                    aux = 1;
                    for (Alumno alumno : listaAlumnos) {
                        System.out.println(aux+ ".- " +alumno.getNombre());
                        aux++;
                    }
                    posicionAlumno = Leer.datoInt();
                    System.out.println(gestion.obtenerAlumno(listaAlumnos, posicionAlumno));
                    break;

                case 4: //Modificar alumnos
                    System.out.println("Que alumno desea modificar");
                    aux = 1;
                    for (Alumno alumno : listaAlumnos) {
                        System.out.println(aux+ ".- " + alumno.getNombre());
                        aux++;
                    }
                    posicionAlumno = Leer.datoInt();
                    gestion.modificarAlumno(listaAlumnos, posicionAlumno);
                    break;

                case 5: //Eliminar alumnos
                    System.out.println("Que alumno desea eliminar");
                    aux = 1;
                    for (Alumno alumno : listaAlumnos) {
                        System.out.println(aux+ ".- " + alumno.getNombre());
                        aux++;
                    }
                    posicionAlumno = Leer.datoInt();
                    gestion.eliminarAlumno(listaAlumnos, posicionAlumno);
                    break;

                default: //Salir
                    repetir = false;
                    break;
            }

        } while (repetir);

        System.out.println("---- Gracias por usar la aplicación ----");
    }
         
            
        }

}
